`pragma protect begin_protected
`pragma protect version="1.0"
`pragma protect author="default"
`pragma protect author_info="default"
`pragma protect encrypt_agent="GOWIN"
`pragma protect encrypt_agent_info="GOWIN Encrypt Version 1.0"

`pragma protect encoding=(enctype="base64", line_length=76, bytes=256)
`pragma protect key_keyowner="GOWIN",key_keyname="GWK2022-11",key_method="rsa"
`pragma protect key_block
sd0eZm2g3Wgo++HxTVDMLcXl3vOmHPRjXzJcpD73MG2V9KhzPzBs976PJEDuZc1SBFghMRWWBIlm
NigdoSuRrOkXXnLFwZKeuZIA/rMot+eaXLMIaNhbXCydcWA0v9MBiaJOIC4eRD3TkEhUcLHNcV/e
DxhqY5NOwAXNMIlogqUgQcZToHmeFRt393lFxpgOOco0c5t/tK/K0xMNmySUqZvO4lXKGA6Qkv1m
9E4GhqY5dQDSrfCDJGmSv7F37I8q8EpUvL+k8n3Wl8aaBIwBn8Nx5cERFTJ8YULeliP+9i8NVH2L
7IakkQI3k2DcmbhpuT0YDaV4+WyZQ4dhqzI/sg==

`pragma protect encoding=(enctype="base64", line_length=76, bytes=368)
`pragma protect data_keyowner="default-ip-vendor"
`pragma protect data_keyname="default-ip-key"
`pragma protect data_method="aes128-cbc"
`pragma protect data_block
SwwQm+JKj7r65VD4+P8EFiLa9RF3C53ye56AuR4pdfEkbUjIA7DW81WF/50ewBF/3u/gXodEYzfl
QoKwtbbix77U5Lnd1k2Qqsv2l2riMqgTio3iT7MQ77Vh9Z10kf9rrsQNPF3TvuXK1//KaqwsVHlb
DhIZo/nW9d6AwmC3dpzIFLyOff120+G3QBzXf5morGLVLPonqrLkMabkQ/v6td24WgAbGsKB79+t
MNylKae/AXfYn3fM1GAvoe2gGhWhs84TMfxusj6TNAg1imv4HiAiQv/V2GRz7tplxUe2uFDOaf5L
i0ys7SW0S5+Xw6J4HigztbDc0yinsrbeRS/t9iXDM3c3RmJczKHcbLTBjXubEMBsIzVyb7b3I4ji
12g17IUnA3hESSQnt+agzYZjqW8VwmaGcU3H6DUL+3pB4dsBNmQ3mYDzr1+oKz/25FNWHUO3rpb6
uVea1ysk8edFH5QPSgTv5MyFw35GByqnw5o=
`pragma protect end_protected
